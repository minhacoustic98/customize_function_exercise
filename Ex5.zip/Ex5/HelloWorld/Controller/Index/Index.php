<?php
namespace Ex5\HelloWorld\Controller\Index;

class Index extends \Magento\Framework\App\Action\Action
{
    protected $_pageResultFactory;

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $pageFactory
    )
    {
        $this->_pageResultFactory=$pageFactory;
        return parent::__construct($context);
    }

    public function execute()
    {
        return $this->_pageResultFactory->create();
    }

    public function renderText()
    {
        return __('Hello World!!!');
    }
}