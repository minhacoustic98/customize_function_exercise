<?php
namespace Ex5\HelloWorld\Block;

class HelloWorld extends \Magento\Framework\View\Element\Template
{
    public function getCustomizeText()
    {
        return __('Hello World!!!');
    }
}