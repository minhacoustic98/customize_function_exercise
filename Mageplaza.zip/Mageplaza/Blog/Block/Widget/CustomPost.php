<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_Blog
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\Blog\Block\Widget;

use Magento\Widget\Block\BlockInterface;
use Magento\Framework\View\Element\Template;
use Mageplaza\Blog\Helper\Data;
use Mageplaza\Blog\Helper\Image;
/**
 * Class Posts
 * @package Mageplaza\Blog\Block\Widget
 */

class CustomPost extends Template implements BlockInterface
{


    protected $_postFactory;
    protected $_postCollectionFactory;
    protected $_helperData;
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Mageplaza\Blog\Model\PostFactory $postFactory,
        \Mageplaza\Blog\Model\ResourceModel\Post\CollectionFactory $collectionFactory,
        array $data=[],
        Data $helper
    )
    {
        $this->_postFactory=$postFactory;
        $this->_postCollectionFactory=$collectionFactory;
        $this->_helperData=$helper;
        parent::__construct($context,$data);
        $this->setTemplate("widget/mypost.phtml");
    }

    public function getSpecific()
    {
        if($this->hasData('postselectors'))

        {
            if($this->getData('postselectors')!=0){
                $collection=$this->_postFactory->create()->load($this->getData('postselectors'));
            }
            else{
                $collection=$this->_postCollectionFactory->create();
            }
        }
      

        return $collection;
    }

    public function getPostId()
    {
        return $this->getData('postselectors');
    }

    public function getTitle()
    {
        return $this->getData('title');
    }

    public function getDescription()
    {
        return $this->getData('description');
    }

    public function getIsSlide()
    {
        return $this->getData('slider');
    }

    public function getFormat()
    {
        return $this->getData('format');
    }

    public function getNumber()
    {
        return $this->getData('post_count');
    }

    public function getImageUrl($image, $type = Image::TEMPLATE_MEDIA_TYPE_POST)
    {
        $imageHelper = $this->_helperData->getImageHelper();
        $imageFile = $imageHelper->getMediaPath($image, $type);

        return $this->_helperData->getImageHelper()->getMediaUrl($imageFile);
    }
}