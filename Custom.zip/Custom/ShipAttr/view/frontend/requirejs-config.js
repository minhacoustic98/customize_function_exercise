var config = {
    "map": {
        "*": {
            "Magento_Checkout/js/model/shipping-save-processor/default" : "Custom_ShipAttr/js/shipping-save-processor-default-override"
        }
    }
};