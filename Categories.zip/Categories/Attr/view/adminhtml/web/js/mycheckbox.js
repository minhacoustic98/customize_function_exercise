define([
    'underscore',
    'uiRegistry',
    'Magento_Ui/js/form/element/single-checkbox',
    'Magento_Ui/js/modal/modal'
], function(_,uiRegistry,select,modal,ko) {
    'use strict';
    
    return select.extend({


        initialize: function () {
            this._super();
 
            this.fieldDepend(this.value());
 
            return this;
 
        },
 
        onUpdate: function (value)
        {
         console.log(value);
 
            var minh_catalog_attribute = uiRegistry.get('index = minh_catalog_attribute'); // get field
 
            var name = uiRegistry.get('index = name'); // get fieldset
 
            if (value == 0) {
 
                minh_catalog_attribute.hide();
 
                name.hide();
            }
 
            else {
 
                minh_catalog_attribute.show();
 
                name.show();
 
            }
            return this._super();
 
        },
        fieldDepend: function (value)
 
        {
            setTimeout( function(){
                var minh_catalog_attribute = uiRegistry.get('index = minh_catalog_attribute');
 
                var name = uiRegistry.get('index = name');
 
                 if (value == 0) {
 
                    minh_catalog_attribute.hide();
 
                    name.hide();
                 }
 
                else {
 
                    minh_catalog_attribute.show();
 
                    name.show();
 
                }
 
            });
 
        }
    });
});