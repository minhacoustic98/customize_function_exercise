var config = {
    'paths': {
        mycheckbox: 'Categories/js/mycheckbox'
    }
 };