<?php
namespace Categories\Attr\Setup;

use Magento\Framework\Setup\InstallDataInterface;
use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;

class InstallData implements InstallDataInterface
{
    private $eavSetupFactory;

    public function __construct(
        EavSetupFactory $eavSetupFactory
    )
    {
        $this->eavSetupFactory=$eavSetupFactory;
    }

    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $eavSetup=$this->eavSetupFactory->create(['setup'=>$setup]);

        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Category::ENTITY,
            'minh_is_landing',
            [
                'type'=>'int',
                'label'=>'Is landing',
                'input'=>'boolean',
                'source'=>'Magento\Eav\Model\Entity\Attribute\Source\Boolean',
                'visible'=>true,
                'default'=>'0',
                'required'=>false,
                'global'=>\Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                'group'=>'Content',
                'backend'=>''
            ]
        )
        
        
        
        ->addAttribute(
            \Magento\Catalog\Model\Category::ENTITY,
            'minh_catalog_attribute',
            [
                'type'=>'varchar',
                'label'=>'Thumbnail image',
                'input'=>'text',
                'sort_order'=>100,
                'source'=>'',
                'global'=>\Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                'visible'=>true,
                'required'=>false,
                'user_defined'=>false,
                'default'=>null,
                'group'=>'Content',
                'backend'=>''
            ]
        )
        ;
    }
}